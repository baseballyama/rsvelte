//! SHA-256 (FIPS 180-4), for outputs a tool derives from a digest: `@vitejs/plugin-vue`'s scope
//! identifier is the first eight hex digits of the SHA-256 of the component's path.

const H0: [u32; 8] = [
    0x6A09_E667,
    0xBB67_AE85,
    0x3C6E_F372,
    0xA54F_F53A,
    0x510E_527F,
    0x9B05_688C,
    0x1F83_D9AB,
    0x5BE0_CD19,
];

#[must_use]
pub fn sha256(data: &[u8]) -> [u8; 32] {
    if data.len() < 56 {
        let mut block = [0u8; 64];
        block[..data.len()].copy_from_slice(data);
        block[data.len()] = 0x80;
        block[56..].copy_from_slice(&((data.len() as u64) * 8).to_be_bytes());
        let mut h = H0;
        sha2::block_api::compress256(&mut h, &[block]);
        let mut out = [0u8; 32];
        for (o, word) in out.as_chunks_mut::<4>().0.iter_mut().zip(h) { *o = word.to_be_bytes(); }
        return out;
    }
    let mut h = H0;
    let bit_len = (data.len() as u64).wrapping_mul(8);
    let (blocks, rest) = data.as_chunks::<64>();
    if !blocks.is_empty() { sha2::block_api::compress256(&mut h, blocks); }
    let mut tail = [0u8; 128];
    tail[..rest.len()].copy_from_slice(rest);
    tail[rest.len()] = 0x80;
    let tail_len = if rest.len() < 56 { 64 } else { 128 };
    tail[tail_len - 8..tail_len].copy_from_slice(&bit_len.to_be_bytes());
    sha2::block_api::compress256(&mut h, tail[..tail_len].as_chunks::<64>().0);
    let mut out = [0u8; 32];
    for (o, word) in out.as_chunks_mut::<4>().0.iter_mut().zip(h) {
        *o = word.to_be_bytes();
    }
    out
}

/// Lowercase hex of `bytes`.
#[must_use]
pub fn hex(bytes: &[u8]) -> String {
    const DIGITS: &[u8; 16] = b"0123456789abcdef";
    let mut s = String::with_capacity(bytes.len() * 2);
    for b in bytes {
        s.push(char::from(DIGITS[usize::from(b >> 4)]));
        s.push(char::from(DIGITS[usize::from(b & 15)]));
    }
    s
}

#[cfg(test)]
mod tests {
    use super::*;

    // FIPS 180-4 examples, and a message whose padding needs a second block.
    #[test]
    fn known_digests() {
        assert_eq!(
            hex(&sha256(b"")),
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        );
        assert_eq!(
            hex(&sha256(b"abc")),
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        );
        assert_eq!(
            hex(&sha256(
                b"abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq"
            )),
            "248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1"
        );
        assert_eq!(
            hex(&sha256(&vec![b'a'; 1_000_000])),
            "cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0"
        );
    }
}
