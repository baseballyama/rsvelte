#![allow(dead_code)]
mod baseline;
mod blocks;
mod short;
mod combined;
mod hybrid;
mod merged;
use sha2::{Digest, Sha256};
use std::{hint::black_box, time::Instant};
fn high(data: &[u8]) -> [u8;32] { Sha256::digest(data).into() }
fn ring_hash(data: &[u8]) -> [u8;32] { ring::digest::digest(&ring::digest::SHA256, data).as_ref().try_into().unwrap() }
fn main() {
    let arms: [(&str, fn(&[u8])->[u8;32]);8] = [("baseline",baseline::sha256),("sha2",high),("blocks",blocks::sha256),("short",short::sha256),("ring",ring_hash),("combined",combined::sha256),("hybrid",hybrid::sha256),("merged",merged::sha256)];
    let mut seed = 123456789u64;
    for n in (0..=4096).chain([65536,1048576]) {
        let data: Vec<u8> = (0..n).map(|_| {seed ^= seed<<13; seed ^= seed>>7; seed ^= seed<<17; seed as u8}).collect();
        let expected = ring_hash(&data);
        for (name,f) in arms { assert_eq!(f(&data),expected,"{name} length {n}"); }
    }
    eprintln!("verified 4099 inputs against ring 0.17.14; sha2 0.11.0; sha2 feature={}",std::arch::is_aarch64_feature_detected!("sha2"));
    let paths: Vec<Vec<u8>> = include_str!("../paths.txt").lines().map(|s|s.as_bytes().to_vec()).collect();
    eprintln!("paths {}",paths.len());
    let mut groups = vec![("paths".to_string(),paths)];
    for n in [0,8,32,55,56,63,64,65,119,120,127,128,256,1024,16384,1048576] {
        groups.push((format!("bytes-{n}"),vec![vec![b'x';n]]));
    }
    println!("group,arm,round,ns_per_hash,iterations,population");
    for (group,data) in groups {
        let bytes: usize = data.iter().map(Vec::len).sum();
        let repeats = (100000usize / data.len()).min(64000000 / bytes.max(1)).max(1);
        for (_,f) in arms { for input in &data {black_box(f(black_box(input)));} }
        for round in 0..16 {
            let order: Vec<usize> = if round%4==0 || round%4==3 {(0..arms.len()).collect()}else{(0..arms.len()).rev().collect()};
            for i in order {
                let (name,f) = arms[i]; let start = Instant::now();
                for _ in 0..repeats { for input in &data {black_box(f(black_box(input)));} }
                let ns = start.elapsed().as_nanos() as f64 / (repeats*data.len()) as f64;
                println!("{group},{name},{round},{ns:.3},{},{}",repeats*data.len(),data.len());
            }
        }
    }
}
